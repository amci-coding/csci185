/* 
cat:  images/cat.jpg
dog:  images/dog.jpeg
bird: images/bird.jpg
fish: images/fish.jpg
*/


function showCat() {
    // your code here...
    console.log('update the image to show a cat!');
};

function showDog() {
    // your code here...
    console.log('update the image to show a dog!');
};

function showBird() {
    // your code here...
    console.log('update the image to show a bird!');
};

function showFish() {
    // your code here...
    console.log('update the image to show a fish!');
};

