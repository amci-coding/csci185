function changeColor() {
    document.querySelector('.panel').style.background = 'hotpink';
};

function changeTitle() {
    //what do we want to change?
    
};

function addImage() {
    // adds the following image to each panel:
    // 1. what element do you want to select?
    //`<img src="../02-attribute-demo/images/fish.jpg" />`;

};

function clearDiv() {
    // clears all of the panels of content
};
