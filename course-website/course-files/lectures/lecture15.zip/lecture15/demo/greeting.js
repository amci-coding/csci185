function sayHello() {
	document.querySelector('#message').innerHTML = '<p>Hello!</p>';
}

function sayGoodbye() {
	document.querySelector('#message').innerHTML = '<p>Goodbye!</p>';
}