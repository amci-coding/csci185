const imgOn = "images/pic_bulbon.gif";
const imgOff = "images/pic_bulboff.gif";
const elem = document.querySelector("#my_image");

function turnOn() {
    // Mr. Kitchen: because we need to use relative paths (in the video, we were
    // using absolute paths), use the "includes" string function to
    // check if the image matches the string.
    // includes checks if a string is contained within another string:
    
    // example: 
    // if (elem.src.includes(imgOn)) { 
    
    // }
}
