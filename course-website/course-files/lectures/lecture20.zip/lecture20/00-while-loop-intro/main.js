console.log('Hey there! Hope you\'re doing OK!');

// note: this is an infinite loop. This code will crash your browser:
// while (true) {
//     console.log('Hey there! Hope you\'re doing OK!');
// }