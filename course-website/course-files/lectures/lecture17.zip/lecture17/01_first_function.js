// this function takes two arguments and 
// returns the sum of the two arguments:
function addTwoNums(num1, num2) {
    return num1 + num2;
}

const answer1 = addTwoNums(3, 5);
const answer2 = addTwoNums(30, 5);
const answer3 = addTwoNums(answer1, answer2);
console.log('Answer 1:', answer1);
console.log('Answer 2:', answer2);
console.log('Answer 3:', answer3);


